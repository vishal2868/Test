using Demo.Data;
using Demo.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;


namespace Demo.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;
        public HomeController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var email = HttpContext.Session.GetString("UserEmail");

            if (string.IsNullOrEmpty(email))
                return RedirectToAction("Login", "Account");

            var currentUser = _context.Users.FirstOrDefault(u => u.Email == email);
            var allUsers = _context.Users.ToList();

            ViewBag.LoggedInName = currentUser?.FullName ?? "Unknown User";
            return View(allUsers); // Passing user list to view
        }
    }

}
