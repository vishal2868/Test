﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using System.Linq;
using Demo.Models;
using System;
using Demo.Data;
using Microsoft.EntityFrameworkCore;

public class AccountController : Controller
{
    private readonly ApplicationDbContext _context;

    public AccountController(ApplicationDbContext context)
    {
        _context = context;
    }
    public IActionResult Index()
    {
        if (string.IsNullOrEmpty(HttpContext.Session.GetString("UserEmail")))
        {
            return RedirectToAction("Login", "Account");
        }

        return View();
    }

    [HttpGet]
    public IActionResult Register()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Register(RegisterViewModel model)
    {
        if (!ModelState.IsValid)
            return View(model);

        // Check for unique email
        var result = _context.Set<EmailCheckResult>().FromSqlRaw("EXEC sp_CheckEmailExists @p0", model.Email).AsEnumerable().FirstOrDefault();
        if(result !=null && result.EmailCount > 0)
        {
            ModelState.AddModelError("Email", "Email is already in use.");
            return View(model);
        }
        

        var user = new User
        {
            FullName = model.FullName,
            Email = model.Email,
            Mobile = model.Mobile,
            Password = model.Password // Hash in real apps
        };

        _context.Database.ExecuteSqlRaw("EXEC sp_InsertUser @p0,@p1,@p2,@p3", user.FullName, user.Email, user.Mobile, user.Password);
        await _context.SaveChangesAsync();

        return RedirectToAction("Login"); // Or success page
    }
    [HttpGet]
    public IActionResult Login()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        if (!ModelState.IsValid)
            return View(model);

        var user = _context.Users
         .FromSqlInterpolated($"EXEC sp_UserLogin {model.Email}, {model.Password}")
         .AsNoTracking()
         .AsEnumerable() 
         .FirstOrDefault();

        if (user == null)
        {
            ModelState.AddModelError(string.Empty, "Invalid email or password.");
            return View(model);
        }

        // Store user info in session or authenticate with Identity
        HttpContext.Session.SetString("UserEmail", user.Email);

        return RedirectToAction("Index", "Home"); // or any dashboard page
    }
    public IActionResult Logout()
    {
        HttpContext.Session.Clear(); // Clears all session data
        return RedirectToAction("Login", "Account"); // Redirect to login page
    }


}
