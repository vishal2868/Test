﻿using Demo.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;

public class MovieController : Controller
{
    private readonly ApplicationDbContext _context;

    public MovieController(ApplicationDbContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        if (string.IsNullOrEmpty(HttpContext.Session.GetString("UserEmail")))
            return RedirectToAction("Login", "Account");

        var movies = _context.Movies.FromSqlRaw("select * from Movies").ToList();
        return View(movies);
    }

    [HttpGet]
    public IActionResult AddOrEdit(int? id)
    {
        if (id == null)
            return View(new Movie());

        var movie = _context.Movies.Find(id);
        return View(movie);
    }

    [HttpPost]
    public IActionResult AddOrEdit(Movie movie)
    {
        if (!ModelState.IsValid)
            return View(movie);

        if (movie.Id == 0)
            _context.Database.ExecuteSqlRaw("EXEC sp_AddOrEditMovie @p0,@p1,@p2,@p3", movie.Id, movie.Title, movie.Genre, movie.ReleaseDate);
        else
            _context.Database.ExecuteSqlRaw("EXEC sp_AddOrEditMovie @p0,@p1,@p2,@p3", movie.Id, movie.Title, movie.Genre, movie.ReleaseDate);

        _context.SaveChanges();
        return RedirectToAction("Index");
    }

    [HttpPost]
    public IActionResult Delete(int id)
    {
        var movie = _context.Movies.Find(id);
        if (movie != null)
        {
            _context.Database.ExecuteSqlRaw("EXEC sp_DeleteMovie @p0", id);
            _context.SaveChanges();
        }
        return RedirectToAction("Index");
    }

    [HttpPost]
    public IActionResult DeleteMultiple(List<int> ids)
    {
        if(ids !=null && ids.Any())
        {
            string idlist = string.Join(",", ids);
            _context.Database.ExecuteSqlRaw("EXEC sp_DeleteMultipleMovies @p0", idlist);
        }
        var movies = _context.Movies.Where(m => ids.Contains(m.Id)).ToList();
       
        return RedirectToAction("Index");
    }
}
