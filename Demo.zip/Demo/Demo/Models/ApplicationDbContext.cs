﻿using Demo.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Reflection.Emit;

namespace Demo.Data  // Replace with your actual namespace
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Movie> Movies { get; set; }
        public DbSet<EmailCheckResult> EmailCheckResults { get; set; }


        // Optional: configure model using Fluent API if needed
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>()
                .HasIndex(u => u.Email)
                .IsUnique(); // Unique email constraint
                
            // Configure EmailCheckResult as a keyless entity (for stored procedure results)
            modelBuilder.Entity<EmailCheckResult>()
                .HasNoKey()
                .ToView(null); // This entity doesn't map to a table
        }
    }
}
