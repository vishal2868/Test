﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using System.Linq;
using Demo.Models;
using System;
using Demo.Data;
using Microsoft.EntityFrameworkCore;

public class AccountController : Controller
{
    private readonly ApplicationDbContext _context;

    public AccountController(ApplicationDbContext context)
    {
        _context = context;
    }
    public IActionResult Index()
    {
        if (string.IsNullOrEmpty(HttpContext.Session.GetString("UserEmail")))
        {
            return RedirectToAction("Login", "Account");
        }

        return View();
    }

    [HttpGet]
    public IActionResult Register()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Register(RegisterViewModel model)
    {
        if (!ModelState.IsValid)
        {
            // Check if it's an AJAX request
            if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
            {
                return Json(new { success = false, message = "Invalid input data." });
            }
            return View(model);
        }

        try
        {
            // Check for unique email
            var result = _context.Set<EmailCheckResult>().FromSqlRaw("EXEC sp_CheckEmailExists @p0", model.Email).AsEnumerable().FirstOrDefault();
            if(result != null && result.EmailCount > 0)
            {
                // Check if it's an AJAX request
                if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
                {
                    return Json(new { success = false, message = "Email is already in use." });
                }
                
                ModelState.AddModelError("Email", "Email is already in use.");
                return View(model);
            }
            
            var user = new User
            {
                FullName = model.FullName,
                Email = model.Email,
                Mobile = model.Mobile,
                Password = model.Password // Hash in real apps
            };

            _context.Database.ExecuteSqlRaw("EXEC sp_InsertUser @p0,@p1,@p2,@p3", user.FullName, user.Email, user.Mobile, user.Password);
            await _context.SaveChangesAsync();

            // Check if it's an AJAX request
            if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
            {
                return Json(new { 
                    success = true, 
                    message = "Account created successfully!", 
                    redirectUrl = Url.Action("Login", "Account") 
                });
            }

            return RedirectToAction("Login"); // Or success page
        }
        catch (Exception ex)
        {
            // Check if it's an AJAX request
            if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
            {
                return Json(new { success = false, message = "An error occurred while creating your account. Please try again." });
            }
            
            ModelState.AddModelError(string.Empty, "An error occurred while creating your account. Please try again.");
            return View(model);
        }
    }

    // AJAX-specific registration method
    [HttpPost]
    public async Task<IActionResult> RegisterAjax(RegisterViewModel model)
    {
        if (!ModelState.IsValid)
        {
            return Json(new { success = false, message = "Invalid input data." });
        }

        try
         {
            // Check for unique email
            var result = _context.Set<EmailCheckResult>().FromSqlRaw("EXEC sp_CheckEmailExists @p0", model.Email).AsEnumerable().FirstOrDefault();
            if(result != null && result.EmailCount > 0)
            {
                return Json(new { success = false, message = "Email is already in use." });
            }
            
            var user = new User
            {
                FullName = model.FullName,
                Email = model.Email,
                Mobile = model.Mobile,
                Password = model.Password // Hash in real apps
            };

            _context.Database.ExecuteSqlRaw("EXEC sp_InsertUser @p0,@p1,@p2,@p3", user.FullName, user.Email, user.Mobile, user.Password);
            await _context.SaveChangesAsync();

            return Json(new { 
                success = true, 
                message = "Account created successfully!", 
                redirectUrl = Url.Action("Login", "Account") 
            });
        }
        catch (Exception ex)
        {
            return Json(new { success = false, message = "An error occurred while creating your account. Please try again." });
        }
    }

    // Test endpoint to verify routing
    [HttpGet]
    public IActionResult Test()
    {
        return Json(new { message = "Controller is working!", timestamp = DateTime.Now });
    }

    // Email availability check endpoint
    [HttpGet]
    public IActionResult IsEmailAvailable(string email)
    {
        try
        {
            var result = _context.Set<EmailCheckResult>().FromSqlRaw("EXEC sp_CheckEmailExists @p0", email).AsEnumerable().FirstOrDefault();
            bool isAvailable = result == null || result.EmailCount == 0;
            return Json(isAvailable);
        }
        catch
        {
            return Json(true); // Default to available if there's an error
        }
    }

    [HttpGet]
    public IActionResult Login()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        if (!ModelState.IsValid)
        {
            // Check if it's an AJAX request
            if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
            {
                return Json(new { success = false, message = "Invalid input data." });
            }
            return View(model);
        }

        var user = _context.Users
         .FromSqlInterpolated($"EXEC sp_UserLogin {model.Email}, {model.Password}")
         .AsNoTracking()
         .AsEnumerable() 
         .FirstOrDefault();

        if (user == null)
        {
            // Check if it's an AJAX request
            if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
            {
                return Json(new { success = false, message = "Invalid email or password." });
            }
            
            ModelState.AddModelError(string.Empty, "Invalid email or password.");
            return View(model);
        }

        // Store user info in session or authenticate with Identity
        HttpContext.Session.SetString("UserEmail", user.Email);

        // Check if it's an AJAX request
        if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
        {
            return Json(new { 
                success = true, 
                message = "Login successful!", 
                redirectUrl = Url.Action("Index", "Home") 
            });
        }

        return RedirectToAction("Index", "Home"); // or any dashboard page
    }

    // Alternative AJAX-specific login method
    [HttpPost]
    public async Task<IActionResult> LoginAjax(LoginViewModel model)
    {
        if (!ModelState.IsValid)
        {
            return Json(new { success = false, message = "Invalid input data." });
        }

        var user = _context.Users
         .FromSqlInterpolated($"EXEC sp_UserLogin {model.Email}, {model.Password}")
         .AsNoTracking()
         .AsEnumerable() 
         .FirstOrDefault();

        if (user == null)
        {
            return Json(new { success = false, message = "Invalid email or password." });
        }

        // Store user info in session
        HttpContext.Session.SetString("UserEmail", user.Email);

        return Json(new { 
            success = true, 
            message = "Login successful!", 
            redirectUrl = Url.Action("Index", "Home") 
        });
    }

    public IActionResult Logout()
    {
        HttpContext.Session.Clear(); // Clears all session data
        return RedirectToAction("Login", "Account"); // Redirect to login page
    }


}
