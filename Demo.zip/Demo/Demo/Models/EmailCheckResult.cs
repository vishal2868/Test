namespace Demo.Models
{
    public class EmailCheckResult
    {
        public int EmailCount { get; set; }
    }
} 